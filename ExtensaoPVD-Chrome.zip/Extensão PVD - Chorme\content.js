// === MODAL DE LOGIN ===
const loginModal = document.createElement("div");
loginModal.style.position = "fixed";
loginModal.style.top = "0";
loginModal.style.left = "0";
loginModal.style.width = "100%";
loginModal.style.height = "100%";
loginModal.style.backgroundColor = "rgba(0,0,0,0.6)";
loginModal.style.display = "none";
loginModal.style.alignItems = "center";
loginModal.style.justifyContent = "center";
loginModal.style.zIndex = "10000";
loginModal.id = "telalogin"; 

const loginBox = document.createElement("div");
loginBox.style.backgroundColor = "#fff";
loginBox.style.padding = "30px 25px 25px 25px";
loginBox.style.borderRadius = "12px";
loginBox.style.boxShadow = "0 10px 30px rgba(65, 88, 208, 0.3)";
loginBox.style.display = "flex";
loginBox.style.flexDirection = "column";
loginBox.style.width = "320px";
loginBox.style.gap = "15px";
loginBox.style.position = "relative";

// Ícone no topo
const iconTop = document.createElement("img");
iconTop.src = chrome.runtime.getURL("icon.png");  // use o mesmo ícone da extensão
iconTop.alt = "Ícone Login";
iconTop.style.width = "60px";
iconTop.style.height = "60px";
iconTop.style.margin = "0 auto 5px auto";
iconTop.style.display = "block";
iconTop.style.borderRadius = "3px";
loginBox.appendChild(iconTop);

const loginTitle = document.createElement("h3");
loginTitle.textContent = "Fazer login";
loginTitle.style.margin = "0";
loginTitle.style.textAlign = "center";
loginTitle.style.fontFamily = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
loginTitle.style.color = "#293462";
loginTitle.style.fontWeight = "700";
loginTitle.style.fontSize = "1.5rem";
loginBox.appendChild(loginTitle);

// Botão fechar modal login
const btnFecharLogin = document.createElement("button");
btnFecharLogin.textContent = "×";
btnFecharLogin.title = "Fechar";
btnFecharLogin.style.position = "absolute";
btnFecharLogin.style.top = "12px";
btnFecharLogin.style.right = "18px";
btnFecharLogin.style.background = "transparent";
btnFecharLogin.style.border = "none";
btnFecharLogin.style.fontWeight = "bold";
btnFecharLogin.style.fontSize = "28px";
btnFecharLogin.style.color = "#888";
btnFecharLogin.style.cursor = "pointer";
btnFecharLogin.style.transition = "color 0.3s ease";
btnFecharLogin.addEventListener("mouseenter", () => btnFecharLogin.style.color = "#4158d0");
btnFecharLogin.addEventListener("mouseleave", () => btnFecharLogin.style.color = "#888");
loginBox.appendChild(btnFecharLogin);

btnFecharLogin.addEventListener("click", () => {
  loginModal.style.display = "none";  
  container.style.display = "none";
  btnAbrir.style.display = "flex"; // mostra botão para reabrir
});

const inputEmail = document.createElement("input");
inputEmail.type = "email";
inputEmail.placeholder = "E-mail";
inputEmail.style.padding = "12px 15px";
inputEmail.style.borderRadius = "8px";
inputEmail.style.border = "1.5px solid #ccc";
inputEmail.style.fontSize = "1rem";
inputEmail.style.fontFamily = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
inputEmail.style.transition = "border-color 0.3s ease";
inputEmail.addEventListener("focus", () => inputEmail.style.borderColor = "#4158d0");
inputEmail.addEventListener("blur", () => inputEmail.style.borderColor = "#ccc");

const inputSenha = document.createElement("input");
inputSenha.type = "password";
inputSenha.placeholder = "Senha";
inputSenha.style.padding = "12px 15px";
inputSenha.style.borderRadius = "8px";
inputSenha.style.border = "1.5px solid #ccc";
inputSenha.style.fontSize = "1rem";
inputSenha.style.fontFamily = "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif";
inputSenha.style.transition = "border-color 0.3s ease";
inputSenha.addEventListener("focus", () => inputSenha.style.borderColor = "#4158d0");
inputSenha.addEventListener("blur", () => inputSenha.style.borderColor = "#ccc");

const btnLogin = document.createElement("button");
btnLogin.textContent = "Entrar";
btnLogin.style.padding = "12px";
btnLogin.style.backgroundColor = "#4158d0";
btnLogin.style.color = "#fff";
btnLogin.style.border = "none";
btnLogin.style.borderRadius = "8px";
btnLogin.style.fontWeight = "600";
btnLogin.style.fontSize = "1.1rem";
btnLogin.style.cursor = "pointer";
btnLogin.style.transition = "background-color 0.3s ease";
btnLogin.addEventListener("mouseenter", () => btnLogin.style.backgroundColor = "#2f3db7");
btnLogin.addEventListener("mouseleave", () => btnLogin.style.backgroundColor = "#4158d0");




const loginErro = document.createElement("div");
loginErro.style.color = "crimson";
loginErro.style.textAlign = "center";
loginErro.style.fontWeight = "600";
loginErro.style.display = "none";
loginErro.style.minHeight = "1.2em";

const loadingOverlay = document.createElement("div");
loadingOverlay.style.position = "absolute";
loadingOverlay.style.top = "0";
loadingOverlay.style.left = "0";
loadingOverlay.style.width = "100%";
loadingOverlay.style.height = "100%";
loadingOverlay.style.backgroundColor = "rgba(255, 255, 255, 0.8)";
loadingOverlay.style.display = "none";
loadingOverlay.style.alignItems = "center";
loadingOverlay.style.justifyContent = "center";
loadingOverlay.style.borderRadius = "12px";
loadingOverlay.style.zIndex = "1000";

// Spinner estilizado simples
const spinner = document.createElement("div");
spinner.style.border = "6px solid #ccc";
spinner.style.borderTop = "6px solid #4158d0";
spinner.style.borderRadius = "50%";
spinner.style.width = "40px";
spinner.style.height = "40px";
spinner.style.animation = "spin 1s linear infinite";

loadingOverlay.appendChild(spinner);
loginBox.appendChild(loadingOverlay);

// Adicione também o CSS para animação spin (adicione no <style> do documento ou via JS):
const style = document.createElement("style");
style.textContent = `
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}`;
document.head.appendChild(style);
loginBox.appendChild(inputEmail);
loginBox.appendChild(inputSenha);
loginBox.appendChild(btnLogin);
loginBox.appendChild(loginErro);

loginModal.appendChild(loginBox);
document.body.appendChild(loginModal);

//===final login modal

// === CRIA INTERFACE FLUTUANTE ===
const container = document.createElement("div");
container.style.position = "fixed";
container.style.right = "20px";
container.style.zIndex = "9999";
container.style.borderRadius = "8px";
container.style.boxShadow = "0 0 10px rgb(255, 255, 255)";
container.style.width = "auto";
container.style.boxSizing = "border-box";
container.style.display = "none";
container.style.flexDirection = "column";
container.style.alignItems = "center";
container.style.justifyContent = "flex-start";
container.style.gap = "4px";
container.style.maxHeight = "auto";
container.style.backgroundColor = "#dc3545";
container.style.paddingBottom = "5px"
container.style.marginTop = "10px";


// === Botão fechar ===
const fecharBtn = document.createElement("button");
fecharBtn.textContent = "×";
fecharBtn.title = "Fechar";
fecharBtn.style.position = "absolute";
fecharBtn.style.top = "5px";
fecharBtn.style.right = "5px";
fecharBtn.style.background = "transparent";
fecharBtn.style.border = "none";
fecharBtn.style.fontWeight = "bold";
fecharBtn.style.fontSize = "20px";
fecharBtn.style.cursor = "pointer";
//container.appendChild(fecharBtn);

// === Header: ícone + label lado a lado ===
const header = document.createElement("div");
header.style.display = "flex";
header.style.alignItems = "center";
header.style.gap = "8px";

const iconeImg = document.createElement("img");
iconeImg.src = chrome.runtime.getURL("icon.png");
iconeImg.alt = "Ícone da extensão";
iconeImg.style.width = "24px";
iconeImg.style.height = "24px";
iconeImg.style.display = "block";

const label = document.createElement("label");
label.textContent = "RPPM Mindfulness BOX";
label.style.fontWeight = "bold";
label.style.textAlign = "center";

header.appendChild(iconeImg);
header.appendChild(label);



//container.appendChild(inputRG);

// === Escolher Vítima ou Autor ===
const envolvimentoWrapper = document.createElement("div");
envolvimentoWrapper.style.display = "flex";
envolvimentoWrapper.style.flexDirection = "column";
envolvimentoWrapper.style.alignItems = "flex-start";
envolvimentoWrapper.style.width = "100%";
envolvimentoWrapper.style.marginTop = "10px";
envolvimentoWrapper.id = "envolvimentoWrapper"; // <-- Adicione esta linha

// Label principal
const labelEnvolvimento = document.createElement("label");
labelEnvolvimento.textContent = "Envolvimento:";
labelEnvolvimento.style.fontWeight = "bold";
labelEnvolvimento.style.marginBottom = "5px";
envolvimentoWrapper.appendChild(labelEnvolvimento);

// Wrapper para os radio buttons
const radioWrapper = document.createElement("div");
radioWrapper.style.display = "flex";
radioWrapper.style.gap = "20px";
radioWrapper.style.alignItems = "center";

// Vítima
const vitimaWrapper = document.createElement("label");
vitimaWrapper.style.display = "flex";
vitimaWrapper.style.alignItems = "center";
vitimaWrapper.style.gap = "5px";
vitimaWrapper.style.cursor = "pointer";

const inputVitima = document.createElement("input");
inputVitima.type = "radio";
inputVitima.name = "envolvimento";
inputVitima.id = "radioVitima";
inputVitima.value = "vitima";

const labelVitima = document.createElement("span");
labelVitima.textContent = "Vítima";

vitimaWrapper.appendChild(inputVitima);
vitimaWrapper.appendChild(labelVitima);

// Autor
const autorWrapper = document.createElement("label");
autorWrapper.style.display = "flex";
autorWrapper.style.alignItems = "center";
autorWrapper.style.gap = "5px";
autorWrapper.style.cursor = "pointer";

const inputAutor = document.createElement("input");
inputAutor.type = "radio";
inputAutor.name = "envolvimento";
inputAutor.id = "radioAutor";
inputAutor.value = "autor";

const labelAutor = document.createElement("span");
labelAutor.textContent = "Autor";

autorWrapper.appendChild(inputAutor);
autorWrapper.appendChild(labelAutor);

// testemunha
const testemunhaWrapper = document.createElement("label");
testemunhaWrapper.style.display = "flex";
testemunhaWrapper.style.alignItems = "center";
testemunhaWrapper.style.gap = "5px";
testemunhaWrapper.style.cursor = "pointer";

const inputTestemunha = document.createElement("input");
inputTestemunha.type = "radio";
inputTestemunha.name = "envolvimento";
inputTestemunha.id = "radiotestemunha";
inputTestemunha.value = "testemunha";

const labelTestemunha = document.createElement("span");
labelTestemunha.textContent = "Testemunha";

testemunhaWrapper.appendChild(inputTestemunha);
testemunhaWrapper.appendChild(labelTestemunha);


// Adiciona ao wrapper geral
radioWrapper.appendChild(vitimaWrapper);
radioWrapper.appendChild(autorWrapper);
radioWrapper.appendChild(testemunhaWrapper);

envolvimentoWrapper.appendChild(radioWrapper);


// === CRIA INTERFACE FLUTUANTE ===
const divPeopleType = document.createElement("div");
      divPeopleType.style.backgroundColor = '#ffffff';
      divPeopleType.style.padding = '16px';
      divPeopleType.style.border = '0px solid #ccc';
      divPeopleType.style.borderRadius = '8px';
      divPeopleType.style.marginBottom = '0px';
      divPeopleType.style.width = 'auto';
      divPeopleType.style.height = 'auto';
      divPeopleType.style.display = 'flex';
      divPeopleType.style.flexDirection = 'column';
      divPeopleType.style.gap = '10px';
      divPeopleType.id = "divContainerFirst"




envolvimentoWrapper.appendChild(divPeopleType);

// Adiciona ao container principal
//container.appendChild(envolvimentoWrapper);


const btnPreencherSemDados = document.createElement("button");
btnPreencherSemDados.textContent = "Preencher dados gerais";
btnPreencherSemDados.style.marginTop = "5px";
btnPreencherSemDados.style.padding = "6px 6px";
btnPreencherSemDados.style.fontWeight = "bold";
btnPreencherSemDados.style.border = "none";
btnPreencherSemDados.style.backgroundColor =  "#4158d0"; 
btnPreencherSemDados.style.color = "#fff";
btnPreencherSemDados.style.borderRadius = "6px";
btnPreencherSemDados.style.cursor = "pointer";
btnPreencherSemDados.style.width = "100%";

//container.appendChild(btnPreencherSemDados);
// === Botão buscar ===
const btnSalvarDados = document.createElement("button");
btnSalvarDados.textContent = "Salvar dados";
btnSalvarDados.style.marginTop = "5px";
btnSalvarDados.style.padding = "6px 6px";
btnSalvarDados.style.fontWeight = "bold";
btnSalvarDados.style.border = "none";
btnSalvarDados.style.backgroundColor =  "#4158d0"; 
btnSalvarDados.style.color = "#fff";
btnSalvarDados.style.borderRadius = "6px";
btnSalvarDados.style.cursor = "pointer";
btnSalvarDados.style.flex = "1";
btnSalvarDados.id = "btnSalvarDados";

//container.appendChild(btnSalvarDados);
// === Botão buscar ===

// === Input RG ===
const inputRG = document.createElement("input");
inputRG.type = "text";
inputRG.id = "rgvitima";
inputRG.style.width = "200px";
inputRG.style.padding = "5px 5px";
inputRG.style.border = "1px solid #aaa";
inputRG.style.borderRadius = "5px";
inputRG.placeholder = "Digite o RG";
inputRG.margin = "10px"
inputRG.display ="none"

const btnBuscar = document.createElement("button");
// Ajusta estilos do botão "Dados Pessoas"
btnBuscar.textContent = "Preencher dados pessoas";
btnBuscar.id = "buscarDados";
btnBuscar.type = "button";
btnBuscar.style.padding = "6px";
btnBuscar.style.fontWeight = "bold";
btnBuscar.style.border = "none";
btnBuscar.style.backgroundColor = "#4158d0";
btnBuscar.style.color = "#fff";
btnBuscar.style.borderRadius = "6px";
btnBuscar.style.cursor = "pointer";
btnBuscar.style.marginTop = "6px";
btnBuscar.style.width = "200px";
btnBuscar.id = "btnBuscar";


const btnLogout = document.createElement("button");
btnLogout.textContent = "Sair"; // Ícone ou letra simples por causa da largura pequena
btnLogout.style.padding = "5"; // Remove padding interno
btnLogout.style.fontWeight = "bold";
btnLogout.style.border = "none";
btnLogout.style.backgroundColor = "#dc3545";
btnLogout.style.color = "#fff";
btnLogout.style.borderRadius = "6px";
btnLogout.style.cursor = "pointer";
btnLogout.style.marginTop = "0";
btnLogout.style.width = "40px";

btnLogout.style.height = "30px";


container.appendChild(btnLogout);


// === Evento: Pressionar Enter aciona "Preencher" ===
inputRG.addEventListener("keydown", function(event) {
  if (event.key === "Enter") {
    event.preventDefault();
    btnBuscar.click();
  }
});


// Cria wrapper para os botões lado a lado
// Cria wrapper para os botões lado a lado
const btnWrapper = document.createElement("div");
btnWrapper.style.display = "flex";
btnWrapper.style.justifyContent = "space-between";
btnWrapper.style.width = "100%";
btnWrapper.style.marginTop = "5px";
btnWrapper.style.gap = "10px"; // Espaço entre os botões



// Faz os botões ocuparem 50% da largura cada

// Adiciona os botões no wrapper
//btnWrapper.appendChild(btnSalvarDados); 
btnWrapper.appendChild(btnLogout);

// Adiciona o wrapper no container ao invés dos botões diretamente
container.appendChild(btnWrapper);


// === Botão abrir flutuante ===
const btnAbrir = document.createElement("button");
btnAbrir.textContent = "Abrir Box";
btnAbrir.style.position = "fixed";
btnAbrir.style.bottom = "20px";
btnAbrir.style.right = "20px";
btnAbrir.style.zIndex = "9999";
btnAbrir.style.padding = "10px 15px";
btnAbrir.style.fontWeight = "bold";
btnAbrir.style.backgroundColor = "#4158d0";
btnAbrir.style.color = "#fff";
btnAbrir.style.border = "none";
btnAbrir.style.borderRadius = "8px";
btnAbrir.style.cursor = "pointer";
btnAbrir.style.display = "none"; // começa escondido

document.body.appendChild(container);
document.body.appendChild(btnAbrir);

// Evento fechar: esconde container, mostra botão abrir
fecharBtn.addEventListener("click", () => {
  container.style.display = "none";
  btnAbrir.style.display = "block";

});

// Evento abrir: só abre a extensão se o usuário estiver autenticado
btnAbrir.addEventListener("click", () => {
  const user = firebase.auth().currentUser;

  if (user) {
    // Usuário autenticado: abre a extensão normalmente
    container.style.display = "flex";
    btnAbrir.style.display = "none";
  } else {
    // Usuário não autenticado: mostra o modal de login
    loginModal.style.display = "flex";
  }
});



function mostrarNotificacao(mensagem, tempo = 3000) {
  const notif = document.createElement("div");
  notif.textContent = mensagem;
  notif.style.position = "fixed";
  notif.style.bottom = "20px";
  notif.style.right = "20px";
  notif.style.background = "#28a745"; // verde sucesso
  notif.style.color = "#fff";
  notif.style.padding = "10px 15px";
  notif.style.borderRadius = "5px";
  notif.style.boxShadow = "0 2px 6px rgba(0,0,0,0.2)";
  notif.style.zIndex = "10000";
  notif.style.fontWeight = "bold";
  notif.style.fontSize = "14px";
  notif.style.transition = "opacity 0.5s ease";

  document.body.appendChild(notif);

  setTimeout(() => {
    notif.style.opacity = "0";
    setTimeout(() => document.body.removeChild(notif), 500);
  }, tempo);

}

function mostrarNotificacao2(mensagem, tempo = 3000) {
  const notif = document.createElement("div");
  notif.textContent = mensagem;
  notif.style.position = "fixed";
  notif.style.bottom = "20px";
  notif.style.right = "20px";
  notif.style.background = "red"; // verde sucesso
  notif.style.color = "#fff";
  notif.style.padding = "10px 15px";
  notif.style.borderRadius = "5px";
  notif.style.boxShadow = "0 2px 6px rgba(0,0,0,0.2)";
  notif.style.zIndex = "10000";
  notif.style.fontWeight = "bold";
  notif.style.fontSize = "14px";
  notif.style.transition = "opacity 0.5s ease";

  document.body.appendChild(notif);

  setTimeout(() => {
    notif.style.opacity = "0";
    setTimeout(() => document.body.removeChild(notif), 500);
  }, tempo);

}

const divDadosGerais = document.getElementById("divContainerFirst");

// start function of initialization
function verificarExibicaoEnvolvimentoWrapper() {
  const campoRG = document.querySelector('input[name="num_documento_id"]');
  const envolvimentoWrapper = document.querySelector('#envolvimentoWrapper');
  const campoPESO = document.querySelector('input[name="vlr_peso_estimado"]');
  const campoSEINDIVIDUO = document.querySelector('input[name="nome_cod_envolvimento"]');  


  
const inputRG = document.getElementById("rgvitima");




// Função para aplicar estilos e manter no foco
function aplicarDegrade(item) {
  if (!item) return;

  // Aplica uma classe para controlar estilos via CSS
  item.classList.add('meu-degrade');

  // Aplica estilos no <a> interno
  const link = item.querySelector('a');
  if (link) {
    link.classList.add('meu-degrade-link');
  }
}



// Seleciona os itens alvo
const item1 = document.querySelector('a[href*="envolvidosList.do"]')?.closest('li');
const item2 = document.querySelector('a[href*="atendimento.do"]')?.closest('li');
const item3 = document.querySelector('a[href*="recursosList.do"]')?.closest('li');
const item4 = document.querySelector('a[href*="destinatariosRecibosList.do"]')?.closest('li');
const item5 = document.querySelector('a[href*="dadosFinais.do"]')?.closest('li');
const item6 = document.querySelector('a[href*="encerrar.do"]')?.closest('li');


aplicarDegrade(item1);
aplicarDegrade(item2);
aplicarDegrade(item3);
aplicarDegrade(item4);
aplicarDegrade(item5);
aplicarDegrade(item6);


if (item1) {
  item1.src = 'https://danieldss030225.github.io/modelosdehistoricopvd/logo.png'; // imagem da web
}


// Injeta as regras CSS para o degradê e foco
const style = document.createElement('style');
style.textContent = `
 .meu-degrade {
  background-color: #4158d0 !important;
  color: #ffffff !important;
  border: none !important;
}

/* Estilo do link */
.meu-degrade-link {
  color: #ffffff !important;
  text-decoration: none !important;
  font-weight: bold !important;
  background: transparent !important;
  outline: none !important;
}

/* Mantém o degradê no fundo do li mesmo no foco */
.meu-degrade:focus,
.meu-degrade:focus-within,
.meu-degrade:active {
  background-color: #4158d0 !important;
  color: #222222 !important; /* texto escuro para contraste */
  outline: none !important;
}

/* Link dentro do li mantém fundo transparente e texto escuro no foco */
.meu-degrade-link:focus,
.meu-degrade-link:focus-visible,
.meu-degrade-link:active {
  background: transparent !important;
  color: #222222 !important;
  outline: none !important;
}

`;
document.head.appendChild(style);

  if (!envolvimentoWrapper) {
    console.warn('Elemento #envolvimentoWrapper não encontrado no DOM.');
    return;
  }


   if (campoPESO) {


  } else if (campoRG) {


  } else if (campoSEINDIVIDUO){ 

      const campoSEINDIVIDUO2 = document.querySelector('input[name="nome_cod_envolvimento"]');  
    if ( campoSEINDIVIDUO2.value == "AUTOR (0100)") {

            document.querySelector('input[id="radioAutor"]').checked = true;
            document.getElementById("switchContainer").style.display = "none";

    } else if ( campoSEINDIVIDUO2.value == "VITIMA DE ACAO CRIMINAL / CIVEL (1301)") {

    const seEX = document.querySelector('select[name="id_relacao_vitima_autor"]').value;
            document.getElementById("switchContainer").style.display = "inline-flex";
                        document.querySelector('input[id="radioVitima"]').checked = true;

     if (seEX == 15) {

        const inputSwit = document.getElementById("inputSwit");
    if (inputSwit) {
      inputSwit.checked = true;
      inputSwit.dispatchEvent(new Event('change')); // Força a atualização visual
    }
    

     } else {
  const inputSwit = document.getElementById("inputSwit");
    if (inputSwit) {
      inputSwit.checked = false;
      inputSwit.dispatchEvent(new Event('change'));
    }
     };


    } else if ( campoSEINDIVIDUO2.value == "TESTEMUNHA QUE TOMOU CONHECIMENTO (1205)") {
  document.getElementById("switchContainer").style.display = "none";
              document.querySelector('input[id="radiotestemunha"]').checked = true;

    }



  }       
}


window.addEventListener('load', verificarExibicaoEnvolvimentoWrapper);

//desenvolvendo esta função
const firebaseConfig = {
    apiKey: "AIzaSyDQWO9csuYqrd0JyXa_cs4f3jAsjQAEWSw",
    authDomain: "meu-site-fd954.firebaseapp.com",
    projectId: "meu-site-fd954",
    storageBucket: "meu-site-fd954.appspot.com",
    messagingSenderId: "1062346912662",
    appId: "1:1062346912662:web:0f41873e12965c545363b7",
    measurementId: "G-5HXX5ZZKER"
  };
firebase.initializeApp(firebaseConfig);
const db = firebase.database();


function inserirTituloComIconAcimaDoTipoPessoa() {
  const spanTipoPessoaLabel = Array.from(document.querySelectorAll('td[colspan="2"] .label'))
    .find(el => el.textContent.trim() === 'Tipo de Pessoa:');

  if (spanTipoPessoaLabel) {
    const td = spanTipoPessoaLabel.closest('td');

    if (td) {
      // Cria o contêiner branco
      const divContainer = document.createElement('div');
      divContainer.style.backgroundColor = '#ffffff';
      divContainer.style.padding = '16px';
      divContainer.style.border = '1px solid #ccc';
      divContainer.style.borderRadius = '8px';
      divContainer.style.marginBottom = '16px';
      divContainer.style.width = 'auto';
      divContainer.style.height = 'auto';
      divContainer.style.display = 'flex';
      divContainer.style.flexDirection = 'column';
      divContainer.style.gap = '10px';
      divContainer.id = "divContainerFirst"

      // Cria o título com ícone
      const titulo = document.createElement('h3');
      titulo.style.margin = '0';
      titulo.style.fontSize = '16px';
      titulo.style.color = '#4158d0';
      titulo.style.fontWeight = '600';
      titulo.style.display = 'flex';
      titulo.style.alignItems = 'center';
      titulo.style.gap = '6px';

      const imgIcon = document.createElement('img');
      imgIcon.src = chrome.runtime.getURL("icon.png");
      imgIcon.style.width = '30px';
      imgIcon.style.height = '30px';
      imgIcon.style.verticalAlign = 'middle';

      titulo.appendChild(imgIcon);
      titulo.appendChild(document.createTextNode('RPPM Mindfulness - Preencher modelo de dados gerais'));

      // Adiciona o título no container
      divContainer.appendChild(titulo);

      // Cria o switch de Companheiro / Ex-companheiro
      const switchWrapper = document.createElement('label');
      switchWrapper.style.display = 'none';
      switchWrapper.style.alignItems = 'center';
      switchWrapper.style.gap = '8px';
      switchWrapper.style.fontSize = '14px';
      switchWrapper.style.color = '#333';
      switchWrapper.style.cursor = 'pointer';
      switchWrapper.id = "switchContainer"; // <--- ADICIONE um id para referência


      const switchLabel = document.createElement('span');
      switchLabel.textContent = 'Companheiro';
      switchLabel.id = "switchID";

      const switchInput = document.createElement('input');
      switchInput.type = 'checkbox';
      switchInput.checked = true;
      switchInput.style.display = 'none';
      switchInput.id = "inputSwit";

      const switchSlider = document.createElement('span');
      switchSlider.style.width = '40px';
      switchSlider.style.height = '20px';
      switchSlider.style.borderRadius = '20px';
      switchSlider.style.backgroundColor = '#4caf50';
      switchSlider.style.position = 'relative';
      switchSlider.style.transition = 'background-color 0.2s';

      const sliderCircle = document.createElement('span');
      sliderCircle.style.position = 'absolute';
      sliderCircle.style.top = '2px';
      sliderCircle.style.left = '2px';
      sliderCircle.style.width = '16px';
      sliderCircle.style.height = '16px';
      sliderCircle.style.borderRadius = '50%';
      sliderCircle.style.backgroundColor = '#fff';
      sliderCircle.style.transition = 'left 0.2s';

      switchSlider.appendChild(sliderCircle);
    const seEXOpe = document.querySelector('select[name="id_relacao_vitima_autor"]');
      
const radioVitima = document.querySelector('input[id="radioVitima"]');  
  

     

      switchInput.addEventListener('change', () => {
        if (switchInput.checked) {
          switchSlider.style.backgroundColor = '#4caf50';
          sliderCircle.style.left = '2px';
          switchLabel.textContent = 'Companheiro';

   
     
                if (seEXOpe) seEXOpe.value = 15;

          
        } else {
          switchSlider.style.backgroundColor = '#f44336';
          sliderCircle.style.left = '22px';
          switchLabel.textContent = 'Ex-companheiro';

                          if (seEXOpe) seEXOpe.value = 16;

        }
      });

      switchWrapper.appendChild(switchInput);
     switchWrapper.appendChild(switchSlider);
      switchWrapper.appendChild(switchLabel);
      divPeopleType.appendChild(switchWrapper);

      // Adiciona o envolvimentoWrapper, se existir
      if (typeof envolvimentoWrapper !== "undefined") {
        divContainer.appendChild(envolvimentoWrapper);
      }

      // Insere o container branco antes da label "Tipo de Pessoa:"
      td.insertBefore(divContainer, spanTipoPessoaLabel);
    }
  } else {
    console.warn('Não foi possível localizar a label "Tipo de Pessoa:"');
  }
}

// Executa quando o DOM estiver pronto
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", inserirTituloComIconAcimaDoTipoPessoa);
} else {
  inserirTituloComIconAcimaDoTipoPessoa();
}




//iniciooo


function inserirBotaoAcimaDeOkEBack() {
  const botaoSalvar = document.querySelector('input[name="ok"]');
  const botaoVoltar = document.querySelector('input[name="back"]');

  if (botaoSalvar && botaoVoltar && botaoSalvar.parentElement === botaoVoltar.parentElement) {
    const td = botaoSalvar.parentElement;

    const novoBotao = document.createElement('button');

    novoBotao.innerHTML = `<img src="${chrome.runtime.getURL("icon.png")}" style="width:16px; height:16px; vertical-align:middle; margin-right:6px;"> RPPM Mindfulness - Salvar`;

    novoBotao.style.display = 'block';
    novoBotao.style.width = '60%';
    novoBotao.style.margin = '0 auto 10px';
    novoBotao.style.backgroundColor = '#4158d0';
    novoBotao.style.color = 'white';
    novoBotao.style.border = 'none';
    novoBotao.style.padding = '8px 16px';
    novoBotao.style.borderRadius = '6px';
    novoBotao.style.cursor = 'pointer';
    novoBotao.style.fontSize = '14px';
    novoBotao.id = "salvarNoDom"; // <-- Adicione esta linha
    novoBotao.type = "button"; // <-- Adicione isto

novoBotao.addEventListener("click", () => {
 aguardarBotaoEAtivar();
});
    

    td.insertBefore(novoBotao, botaoSalvar);
  } else {
    console.warn('Botões "Salvar" e "Voltar" não encontrados ou em elementos diferentes.');
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", inserirBotaoAcimaDeOkEBack);
} else {
  inserirBotaoAcimaDeOkEBack();
}


 
//final

function inserirDivAcimaDoBotaoBuscarDados() {
  const botaoBuscar = document.getElementById("botaoPesquisaIndividuo");

  if (botaoBuscar) {
    const td = botaoBuscar.closest('td');
    const tr = td.closest('tr'); // Linha da tabela onde o botão está
    const tabela = tr.closest('table'); // Tabela que contém tudo

    // Cria nova linha (tr) e célula (td) para ocupar toda a largura
    const novaTR = document.createElement('tr');
    const novaTD = document.createElement('td');
    novaTD.colSpan = tr.children.length; // Ocupar todas as colunas
    novaTR.appendChild(novaTD);

    // Cria a nova div
    const novaDiv = document.createElement('div');
    novaDiv.style.backgroundColor = '#ffffff';
    novaDiv.style.padding = '16px';
    novaDiv.style.border = '1px solid #ccc';
    novaDiv.style.borderRadius = '8px';
    novaDiv.style.marginBottom = '16px';
    novaDiv.style.width = '100%';
    novaDiv.style.display = 'flex';
    novaDiv.style.flexDirection = 'column';
    novaDiv.style.gap = '10px';
    novaDiv.id = "novaDivRG"; // <-- Adicione esta linha



    

    // Cria o título com ícone
      const titulo = document.createElement('h3');
      titulo.style.margin = '0';
      titulo.style.fontSize = '16px';
      titulo.style.color = '#4158d0';
      titulo.style.fontWeight = '600';
      titulo.style.display = 'flex';
      titulo.style.alignItems = 'center';
      titulo.style.gap = '6px';

      const imgIcon = document.createElement('img');
      imgIcon.src = chrome.runtime.getURL("icon.png");
      imgIcon.style.width = '30px';
      imgIcon.style.height = '30px';
      imgIcon.style.verticalAlign = 'middle';

      titulo.appendChild(imgIcon);
      titulo.appendChild(document.createTextNode('🔎 RPPM Mindfulness - Preencher modelo de dados pessoas'));

      // Adiciona o título no container
      novaDiv.appendChild(titulo);
  

    // Monta o conteúdo da div
    novaDiv.appendChild(inputRG);
    novaDiv.appendChild(btnBuscar);

    // Insere div na nova TD
    novaTD.appendChild(novaDiv);

    // Insere nova linha acima da linha do botão
    tr.parentNode.insertBefore(novaTR, tr);

  } else {
    console.warn('Botão "Buscar Dados" não encontrado.');
  }
}

// Executa quando DOM estiver pronto
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", inserirDivAcimaDoBotaoBuscarDados);
} else {
  inserirDivAcimaDoBotaoBuscarDados();
}



inputVitima.addEventListener('change', () => {
  const inputFisica = document.querySelector('input[name="ind_fisica_juridica"][value="F"]');
  const treeSearch = document.getElementById('treeSearch');
  const inputTipoEnvolvimento = document.getElementById('tipoEnvolvimento');

  if (inputVitima.checked) {
    document.getElementById("switchContainer").style.display = "inline-flex";

    mostrarNotificacao("Vítima selecionada!");

    if (inputFisica) {
      inputFisica.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    }

    if (inputTipoEnvolvimento) inputTipoEnvolvimento.value = '';
    if (treeSearch) treeSearch.value = '';

    if (typeof realizaVerificacoes === 'function' && treeSearch) {
      realizaVerificacoes(treeSearch);
    }

    if (typeof $ !== 'undefined' && $.fn.campoHierarquico) {
      $('#tree').campoHierarquico('destroy_tree');
      $('#treeEnvolvimentoSecundario').campoHierarquico('destroy_tree');
    }

    if (typeof retrieveByAjaxTimeout === 'function' && typeof inicializaArvoreTipoEnvolvimentoETipoEnvolvimentoSecudario === 'function') {
      retrieveByAjaxTimeout(
        inicializaArvoreTipoEnvolvimentoETipoEnvolvimentoSecudario,
        1000,
        inputFisica,
        'tipoEnvolvimentoAjax',
        'tipoEnvolvimentoSecundarioAjax'
      );
    }

    // Espera o container #spanTree aparecer no DOM
    const esperaSpanTree = setInterval(() => {
      const spanTree = document.getElementById('spanTree');

      if (spanTree) {
        clearInterval(esperaSpanTree);

        const observer = new MutationObserver((mutations, obs) => {
          const tree = document.getElementById('tree');

          if (tree) {
            const nodeLink = Array.from(tree.querySelectorAll('a')).find(a =>
              a.textContent.trim().toUpperCase() === 'VITIMA DE ACAO CRIMINAL / CIVEL (1301)'
            );

            if (nodeLink) {
              const title = nodeLink.getAttribute('title') || '';
              const codeMatch = title.match(/\((\d+)\)/);

              if (codeMatch) {
                const codigo = codeMatch[1];

                if (inputTipoEnvolvimento) inputTipoEnvolvimento.value = codigo;
                if (treeSearch) treeSearch.value = 'VITIMA DE ACAO CRIMINAL / CIVEL (1301)';

                ['input', 'change'].forEach(evt =>
                  treeSearch.dispatchEvent(new Event(evt, { bubbles: true }))
                );

                nodeLink.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));

                console.log('✅ Item "VÍTIMA DE AÇÃO CRIMINAL / CIVEL (1301)" selecionado com sucesso.');
teste() 
                obs.disconnect();
              }
            }
          }
        });

        observer.observe(spanTree, { childList: true, subtree: true });
      }
    }, 300); // Tenta a cada 300ms até encontrar o spanTree
  }
});





inputAutor.addEventListener('change', () => {
  const inputFisica = document.querySelector('input[name="ind_fisica_juridica"][value="F"]');
  inputFisica.checked.true
  const treeSearch = document.getElementById('treeSearch');
  const inputTipoEnvolvimento = document.getElementById('tipoEnvolvimento');

  if (inputAutor.checked) {
    document.getElementById("switchContainer").style.display = "none";

    mostrarNotificacao("Autor selecionado!");

    if (inputFisica) {
      inputFisica.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    }

    if (inputTipoEnvolvimento) inputTipoEnvolvimento.value = '';
    if (treeSearch) treeSearch.value = '';

    if (typeof realizaVerificacoes === 'function' && treeSearch) {
      realizaVerificacoes(treeSearch);
    }

    if (typeof $ !== 'undefined' && $.fn.campoHierarquico) {
      $('#tree').campoHierarquico('destroy_tree');
      $('#treeEnvolvimentoSecundario').campoHierarquico('destroy_tree');
    }

    if (typeof retrieveByAjaxTimeout === 'function' && typeof inicializaArvoreTipoEnvolvimentoETipoEnvolvimentoSecudario === 'function') {
      retrieveByAjaxTimeout(
        inicializaArvoreTipoEnvolvimentoETipoEnvolvimentoSecudario,
        1000,
        inputFisica,
        'tipoEnvolvimentoAjax',
        'tipoEnvolvimentoSecundarioAjax'
      );
    }

    const esperaSpanTree = setInterval(() => {
      const spanTree = document.getElementById('spanTree');

      if (spanTree) {
        clearInterval(esperaSpanTree);

        const observer = new MutationObserver((mutations, obs) => {
          const tree = document.getElementById('tree');

          if (tree) {
            const nodeLink = Array.from(tree.querySelectorAll('li.jstree-leaf a')).find(a =>
  a.getAttribute('title')?.trim().toUpperCase() === 'AUTOR (0100)'
);


            if (nodeLink) {
              const title = nodeLink.getAttribute('title') || '';
              const codeMatch = title.match(/\((\d+)\)/);

              if (codeMatch) {
                const codigo = codeMatch[1];

                if (inputTipoEnvolvimento) inputTipoEnvolvimento.value = codigo;
                if (treeSearch) treeSearch.value = 'AUTOR (0100)';

                ['input', 'change'].forEach(evt =>
                  treeSearch.dispatchEvent(new Event(evt, { bubbles: true }))
                );

                nodeLink.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
teste() 
                console.log('✅ Item "AUTOR (0100)" selecionado com sucesso.');

                obs.disconnect();
              }
            }
          }
        });

        observer.observe(spanTree, { childList: true, subtree: true });
      }
    }, 300);
  }
});





inputTestemunha.addEventListener('change', () => {
  const inputFisica = document.querySelector('input[name="ind_fisica_juridica"][value="F"]');
  const treeSearch = document.getElementById('treeSearch');
  const inputTipoEnvolvimento = document.getElementById('tipoEnvolvimento');

  if (inputTestemunha.checked) {
    document.getElementById("switchContainer").style.display = "none";

    mostrarNotificacao("Testemunha selecionada!");

    if (inputFisica) {
      inputFisica.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    }

    if (inputTipoEnvolvimento) inputTipoEnvolvimento.value = '';
    if (treeSearch) treeSearch.value = '';

    if (typeof realizaVerificacoes === 'function' && treeSearch) {
      realizaVerificacoes(treeSearch);
    }

    if (typeof $ !== 'undefined' && $.fn.campoHierarquico) {
      $('#tree').campoHierarquico('destroy_tree');
      $('#treeEnvolvimentoSecundario').campoHierarquico('destroy_tree');
    }

    if (typeof retrieveByAjaxTimeout === 'function' && typeof inicializaArvoreTipoEnvolvimentoETipoEnvolvimentoSecudario === 'function') {
      retrieveByAjaxTimeout(
        inicializaArvoreTipoEnvolvimentoETipoEnvolvimentoSecudario,
        1000,
        inputFisica,
        'tipoEnvolvimentoAjax',
        'tipoEnvolvimentoSecundarioAjax'
      );
    }

    // Espera o container #spanTree aparecer no DOM
    const esperaSpanTree = setInterval(() => {
      const spanTree = document.getElementById('spanTree');

      if (spanTree) {
        clearInterval(esperaSpanTree);

        const observer = new MutationObserver((mutations, obs) => {
          const tree = document.getElementById('tree');

          if (tree) {
            const nodeLink = Array.from(tree.querySelectorAll('a')).find(a =>
              a.textContent.trim().toUpperCase() === 'TESTEMUNHA QUE TOMOU CONHECIMENTO (1205)'
            );

            if (nodeLink) {
              const title = nodeLink.getAttribute('title') || '';
              const codeMatch = title.match(/\((\d+)\)/);

              if (codeMatch) {
                const codigo = codeMatch[1];

                if (inputTipoEnvolvimento) inputTipoEnvolvimento.value = codigo;
                if (treeSearch) treeSearch.value = 'TESTEMUNHA QUE TOMOU CONHECIMENTO (1205)';

                ['input', 'change'].forEach(evt =>
                  treeSearch.dispatchEvent(new Event(evt, { bubbles: true }))
                );

                nodeLink.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));

                console.log('✅ Item "TESTEMUNHA QUE TOMOU CONHECIMENTO (1205)" selecionado com sucesso.');
teste() 
                obs.disconnect();
              }
            }
          }
        });

        observer.observe(spanTree, { childList: true, subtree: true });
      }
    }, 300); // Tenta a cada 300ms até encontrar o spanTree
  }
});









function teste() {
  try {
    const campo = (selector) => document.querySelector(selector);

    const input = campo('input[name="nome_cod_envolvimento"]');
    const campoRELACAO = campo('select[name="id_relacao_vitima_autor"]');
    const campoLESAO = campo('select[name="id_condicao_fisica"]');
    const campoPRISAO = campo('select[name="id_tipo_prisao_apreensao"]');
    const campoIMOBILIZACAO = campo('input[name="ind_imobilizacao"]');
    const campoMILITAR = campo('input[name="ind_env_militar_policial"]');
    const campoRESISTENCIA = campo('input[name="ind_resistencia"]');
    const botaoCopia = campo('input[name="copiaNaturezaOcorrencia"]');
    const switIN = document.getElementById("switchID").textContent;
    if (!input || input.value.trim() === "") {
      alert("⚠️ Atenção! Falha ao preencher dados gerais.\n\nVá à página de INDIVÍDUOS e selecione VÍTIMA ou AUTOR.");
      return;
    }

    const valor = input.value.trim().toUpperCase();

    if (valor.includes("AUTOR")) {
      mostrarNotificacao("Dados gerais do autor preenchidos com sucesso!");
      if (campoPRISAO) campoPRISAO.value = 5;
      if (campoIMOBILIZACAO) campoIMOBILIZACAO.checked = true;
    } else if (valor.includes("TESTEMUNHA")) {
          mostrarNotificacao("Dados gerais da testemunha preenchidos com sucesso!");

    } else {
      mostrarNotificacao("Dados gerais da vítima preenchidos com sucesso!");
      if (switIN == "Ex-companheiro") campoRELACAO.value = 16; else {
         campoRELACAO.value = 15;
      }
    }

    if (campoMILITAR) campoMILITAR.checked = true;
    if (campoRESISTENCIA) campoRESISTENCIA.checked = true;
    if (campoLESAO) campoLESAO.value = 5;

    if (botaoCopia) {
      botaoCopia.click();
      console.log("Botão 'Copiar Natureza Principal' acionado.");
    } else {
      alert("⚠️ Botão 'Copiar Natureza Principal' não encontrado!");
    }

  } catch (e) {
    console.error("Erro ao preencher dados gerais:", e);
    alert("⚠️ Erro inesperado ao preencher dados gerais. Verifique o console para mais detalhes.");
  }
};



btnPreencherSemDados.addEventListener("click", () => {
  try {
    const campo = (selector) => document.querySelector(selector);

    const input = campo('input[name="nome_cod_envolvimento"]');
    const campoRELACAO = campo('select[name="id_relacao_vitima_autor"]');
    const campoLESAO = campo('select[name="id_condicao_fisica"]');
    const campoPRISAO = campo('select[name="id_tipo_prisao_apreensao"]');
    const campoIMOBILIZACAO = campo('input[name="ind_imobilizacao"]');
    const campoMILITAR = campo('input[name="ind_env_militar_policial"]');
    const campoRESISTENCIA = campo('input[name="ind_resistencia"]');
    const botaoCopia = campo('input[name="copiaNaturezaOcorrencia"]');

    if (!input || input.value.trim() === "") {
      alert("⚠️ Atenção! Falha ao preencher dados gerais.\n\nVá à página de INDIVÍDUOS e selecione VÍTIMA ou AUTOR.");
      return;
    }

    const valor = input.value.trim().toUpperCase();

    if (valor.includes("AUTOR")) {
      mostrarNotificacao("Dados gerais do autor preenchidos com sucesso!");
      if (campoPRISAO) campoPRISAO.value = 5;
      if (campoIMOBILIZACAO) campoIMOBILIZACAO.checked = true;
    }  else if (valor.includes("TESTEMUNHA")) {  

      mostrarNotificacao("Dados gerais da testemunha preenchidos com sucesso!");

    } else {
      mostrarNotificacao("Dados gerais da vítima preenchidos com sucesso!");
      if (campoRELACAO) campoRELACAO.value = 16;
    }

    if (campoMILITAR) campoMILITAR.checked = true;
    if (campoRESISTENCIA) campoRESISTENCIA.checked = true;
    if (campoLESAO) campoLESAO.value = 4;

    if (botaoCopia) {
      botaoCopia.click();
      console.log("Botão 'Copiar Natureza Principal' acionado.");
    } else {
      alert("⚠️ Botão 'Copiar Natureza Principal' não encontrado!");
    }

  } catch (e) {
    console.error("Erro ao preencher dados gerais:", e);
    alert("⚠️ Erro inesperado ao preencher dados gerais. Verifique o console para mais detalhes.");
  }
});



//THE FUNCTION THAT INITIALIZE THE FIREBASE ARE HERE.



function initFirebase() {
  function realizarLogin() {
    const email = inputEmail?.value.trim();
    const senha = inputSenha?.value;
    const divDadosGerais = document.getElementById("divContainerFirst");

    if (!email || !senha) {
      if (loginErro) {
        loginErro.textContent = "Preencha e-mail e senha.";
        loginErro.style.display = "block";
      }
      return;
    }

    if (loginErro) loginErro.style.display = "none";
    if (loadingOverlay) loadingOverlay.style.display = "flex"; // Mostrar loading

    firebase.auth().signInWithEmailAndPassword(email, senha)
      .then(() => {
        if (loadingOverlay) loadingOverlay.style.display = "none";
        if (loginModal) loginModal.style.display = "none";
        if (container) container.style.display = "flex";
        if (divDadosGerais) divDadosGerais.style.display = "flex";
        if (loginErro) loginErro.style.display = "none";
        if (btnAbrir) btnAbrir.style.display = "none";

        mostrarNotificacao("login realizado com sucesso!");
      })
      .catch((error) => {
        if (loadingOverlay) loadingOverlay.style.display = "none";
        if (loginErro) {
          loginErro.textContent = "Falha no login! Confira suas credenciais e tente novamente";
          loginErro.style.display = "block";
        }
        console.error("Erro ao fazer login:", error);
      });
  }

  // Clique no botão
  btnLogin?.addEventListener("click", () => {
    realizarLogin();
  });

  // Pressionar Enter no login
  document.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      const loginModal = document.getElementById("telalogin");
      const visivel = loginModal && window.getComputedStyle(loginModal).display !== "none";

      if (visivel) {
        event.preventDefault();
        realizarLogin();
      }
    }
  });
  // Verifica se já está logado
  firebase.auth().onAuthStateChanged((user) => {
    const divDadosGerais = document.getElementById("divContainerFirst");
    const inputENVOLVIDO = document.querySelector('input[name="nomeEnvolvimento"]');
    const loginModal = document.getElementById("telalogin");
    const novaDivRG = document.getElementById("novaDivRG");
    const salvarNoDom = document.getElementById("salvarNoDom");

   // if (inputENVOLVIDO) {
      if (user) {
        let botao = document.querySelector('input[name="insert"]');
      //  if (!botao) {
          if (loginModal) loginModal.style.display = "none";
          if (container) container.style.display = "flex";
          if (divDadosGerais) divDadosGerais.style.display = "flex";
          if (novaDivRG) novaDivRG.style.display = "flex";
          if (salvarNoDom) salvarNoDom.style.display = "block";

       // }
      } else {
        if (loginModal) loginModal.style.display = "none";
        if (container) container.style.display = "none";
        if (btnAbrir) btnAbrir.style.display = "block";
        if (divDadosGerais) divDadosGerais.style.display = "none";
        if (novaDivRG) novaDivRG.style.display = "none";
        if (salvarNoDom) salvarNoDom.style.display = "none";

      }
   // }
  });

}






btnBuscar.addEventListener("click", () => { 
  //const campoRGORIGEM = document.querySelector('input[name="num_documento_id"]'); // substitua pelo name real
  const campoRGORIGEM = document.getElementById("rgvitima");


  if (!campoRGORIGEM) {
      alert("⚠️Atenção! Falha ao preencher dados pessoais. Passo a passo: Vá à página dados pessoais do indivíduo e digite o RG do indivíduo!");
    return;
  }

  const rg = campoRGORIGEM.value.trim();

  if (!rg) {
      alert("⚠️Atenção! Falha ao preencher dados pessoais. Passo a passo: Vá à página dados pessoais do indivíduo e digite o RG do indivíduo!");
    return;
  }

  const refPath = "DADOSGERAIS/" + rg;
  const dbRef = db.ref(refPath);

  dbRef.get()
    .then((snapshot) => {
      if (!snapshot.exists()) {
resetarCamposFormulario(); 
    mostrarNotificacao2("⚠️ Campos limpos. RG não encontrado no banco.");

        return;
      }

      let dados;
      try {
        dados = JSON.parse(snapshot.val());
      } catch (e) {
resetarCamposFormulario();   
    mostrarNotificacao2("⚠️ Campos limpos. RG não encontrado no banco.");
     console.error(e);
        return;
      }

      preencherFormulario(dados, rg);
    })
    .catch((error) => {
      console.error("Erro ao buscar dados:", error);
resetarCamposFormulario(); 
    mostrarNotificacao2("⚠️ Campos limpos. RG não encontrado no banco.");
   });
});



btnLogout.addEventListener("click", () => {
  firebase.auth().signOut()
    .then(() => {
      loginModal.style.display = "flex";
      container.style.display = "none";
    })
    .catch((error) => {
      console.error("Erro ao fazer logout:", error);
      alert("Erro ao sair: " + error.message);
    });
});


function normalizarValor(valor) {
  return typeof valor === "string" && valor.trim().toUpperCase() === "NULL" ? "" : valor || "";
}


  // Resto do código (ex: btnBuscar)


function preencherFormulario(dados, rg) {
  try {
    const campoFUNCAO = document.querySelector('input[name="des_ocup_profissional"]');
    const campoNOME = document.querySelector('input[name="nom_compl_envolvido"]');
    const campoCPF = document.querySelector('input[name="num_cpf_cnpj"]');
    const campoRG = document.querySelector('input[name="num_documento_id"]');
    const campoTELEFONE = document.querySelector('input[name="num_telefone_res"]');
    const campoESCOLARIDADE = document.querySelector('select[name="id_escolaridade"]');
    const campoCOR = document.querySelector('select[name="id_cor_pele"]');
    const campoESTADOCIVEL = document.querySelector('select[name="id_estado_civil"]');
    const campoUFRG = document.querySelector('select[name="cod_uf_orgao_exp"]');
    const campoEMAIL = document.querySelector('select[name="id_motivo_ausencia_telmail"]');
    const campoDDDcel = document.querySelector('input[name="ddd_telefone_residencial"]');
    const campoIDGENERO = document.querySelector('select[name="id_identidade_genero"]');
    const campoORGAOEXPEDIDOR = document.querySelector('select[name="id_orgao_exp"]');
    const campoNACIONALIDADE = document.querySelector('select[name="id_nacionalidade"]');
    const campoPAISDEORIGEM = document.querySelector('select[name="id_pais_origem"]');
    const campoNascimento = document.querySelector('input[name="dta_nascimento"]');
    const campoNOMEMAE = document.querySelector('input[name="nom_mae"]');
    const campoNOMEPAI = document.querySelector('input[name="nom_pai"]');
    const campoUFNATURALIDADE = document.querySelector('select[name="cod_uf_natural"]');
    const campoCODESCOLARIODADE = document.querySelector('input[name="escolaridade"]');
   const campoCODCOR = document.querySelector('input[name="cutis"]');
   const campoCODESTADOCIVIL = document.querySelector('input[name="estadoCivil"]');

adicionarOpcaoNaoInformadoSituacaoRua()    
    document.querySelector('input[name="ind_orientacao_sexual"]').checked = true;
    document.querySelector('input[name="ind_identidade_genero"]').checked = true;
    document.querySelector('input[name="ind_turista"]').checked = true;
    //document.querySelector('input[name="ind_mandado_prisao"]').checked = true;
    //document.querySelector('input[name="ind_mandado_prisao_atual"]').checked = true;
const radioMandadoD = document.querySelector('input[name="ind_mandado_prisao"][value="D"]');
if (radioMandadoD) {
  // Por exemplo, marcar como selecionado
  radioMandadoD.checked = true;

  // Ou fazer alguma ação
  console.log("Radio encontrado!");
}
const radioMandadoAtual = document.querySelector('input[name="ind_mandado_prisao_atual"][value="D"]');
if (radioMandadoAtual) {
  // Por exemplo, marcar como selecionado
  radioMandadoAtual.checked = true;

  // Ou fazer alguma ação
  console.log("Radio encontrado!");
}




    campoCODESCOLARIODADE.value = "";
        campoCODCOR.value = "";
        campoCODESTADOCIVIL.value = "";

    campoPAISDEORIGEM.value = 1;
    campoNACIONALIDADE.value = 1;
// Primeiro, executa o clique no item da árvore
const item = Array.from(document.querySelectorAll('li.jstree-leaf a')).find(el =>
  el.textContent.trim() === "CARTEIRA DE IDENTIDADE CIVIL (0801)"
);

if (item) {
  item.click();
} else {
  console.warn("Item da árvore 'CARTEIRA DE IDENTIDADE CIVIL (0801)' não encontrado.");
}

// Depois, tenta focar o inputRG várias vezes, com delay
let tentativas = 0;
const maxTentativas = 30;

function tentarFocar(delay) {
  setTimeout(() => {
    inputRG.focus();
    inputRG.select();
    tentativas++;

    if (document.activeElement !== inputRG && tentativas < maxTentativas) {
      tentarFocar(delay + 100);
    }
  }, delay);
}

tentarFocar(100);


    campoEMAIL.value = 1;
    campoIDGENERO.value = 5;
    campoUFRG.value = "MG";

    const nascimentoBruto = normalizarValor(dados[11]);
    if (nascimentoBruto && campoNascimento) {
      const partes = nascimentoBruto.split("-");
      if (partes.length === 3) {
        const [ano, mes, dia] = [parseInt(partes[0]), parseInt(partes[1]) - 1, parseInt(partes[2])];
        const dataNascimento = new Date(ano, mes, dia);
        const dataFormatada = `${String(dia).padStart(2, '0')}/${String(mes + 1).padStart(2, '0')}/${ano}`;
        campoNascimento.value = dataFormatada;

        const hoje = new Date();
        let idade = hoje.getFullYear() - ano;
        if (hoje.getMonth() < mes || (hoje.getMonth() === mes && hoje.getDate() < dia)) idade--;

        const campoIdade = document.querySelector('input[name="vlr_idade_aparente"]');
        if (campoIdade) campoIdade.value = idade;
      }
    }

    campoDDDcel.value = normalizarValor(dados[14]);
    campoNOMEPAI.value = normalizarValor(dados[10]);
    campoNOMEMAE.value = normalizarValor(dados[9]);
    campoNOME.value = normalizarValor(dados[0]);
    if (rg && campoRG) campoRG.value = rg;
    campoFUNCAO.value = normalizarValor(dados[5]);
    campoCPF.value = normalizarValor(dados[3]);
    campoTELEFONE.value = normalizarValor(dados[1]);



const setSelectValue = (campo, valor) => {
  valor = normalizarValor(valor);
  if (!campo) return;

  // Se o valor for "", tenta selecionar o option vazio
  const option = [...campo.options].find(opt => opt.value === valor);
  if (option) {
    campo.value = valor;
  } else {
    campo.selectedIndex = -0; // ou -1 se quiser nenhuma seleção
  }
};



    setSelectValue(campoESCOLARIDADE, dados[6]);
    setSelectValue(campoCOR, dados[7]);
    setSelectValue(campoESTADOCIVEL, dados[8]);
    setSelectValue(campoORGAOEXPEDIDOR, dados[15]);

    const ufNaturalidade = normalizarValor(dados[12]);

    if (campoUFNATURALIDADE && ufNaturalidade) {
      const optionExists = [...campoUFNATURALIDADE.options].some(opt => opt.value === ufNaturalidade);

      if (optionExists) {
        campoUFNATURALIDADE.value = ufNaturalidade;
        campoUFNATURALIDADE.dispatchEvent(new Event('change'));

        const municipio = normalizarValor(dados[13]);
        if (municipio) {
          esperarMunicipioEPreencher(municipio);
        }
      }
    }

    mostrarNotificacao("Dados pessoais preenchidos com sucesso!");
    verificarNomeEnvolvimento();

  } catch (e) {
    console.error("Erro ao preencher formulário:", e);
    if (e instanceof TypeError && e.message.includes("null")) {
      alert("⚠️Atenção! Falha ao preencher dados pessoais. Passo a passo: Vá à página dados pessoais do indivíduo e digite o RG do indivíduo!");
    } else {
      alert("Erro inesperado ao preencher os dados. Verifique o console.");
    }
  }
}



function esperarMunicipioEPreencher(valorMunicipio, tentativas = 0) {
  const MAX_TENTATIVAS = 15;
  const DELAY = 1000;

  const campoNATURALIDADE = document.querySelector('select[name="cod_municipio_naturalidade"]');
  const botao = document.querySelector('input[name="copiaEnderecoOcorrencia"]');

  if (!campoNATURALIDADE) {
    alert('Campo município não encontrado no DOM.');
    return;
  }

  const municipioExiste = [...campoNATURALIDADE.options].some(opt => opt.value === valorMunicipio);

  if (municipioExiste) {
    campoNATURALIDADE.disabled = false;
    campoNATURALIDADE.value = valorMunicipio;
    campoNATURALIDADE.dispatchEvent(new Event('change'));

    if (botao) {
      botao.click();
    } else {
      console.log('Botão não encontrado!');
    }

  } else {
    if (tentativas < MAX_TENTATIVAS) {
      setTimeout(() => {
        esperarMunicipioEPreencher(valorMunicipio, tentativas + 1);

      }, DELAY);
    } else {
      alert(`Erro ao preencher naturalidade: valor '${valorMunicipio}' não encontrado após ${MAX_TENTATIVAS} tentativas.`);
    }
  }
}

   




// === RODA initFirebase após DOM pronto ===
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initFirebase);
} else {
  initFirebase();
}





function verificarNomeEnvolvimento() {
  const input = document.querySelector('input[name="nomeEnvolvimento"]');
   const campoSEXO = document.querySelector('select[name="cod_sexo"]'); // substitua pelo name real

  if (!input) {
    console.warn('Input com name="nomeEnvolvimento" não encontrado.');
    return;
  }

  const valor = input.value.toUpperCase(); // ignora diferenciação de maiúsculas
  if (valor.includes("VITIMA")) {
    // ✅ Ação se contiver "VITIMA"
    console.log("É vítima — executando ação A");
    
    campoSEXO.value = "F";


    // ... coloque aqui o que quiser executar
  } else {
    // ❌ Ação se não contiver "VITIMA"
    console.log("Não é vítima — executando ação B");
    // ... outra ação
   campoSEXO.value = "M";

  }
}



function salvarDadosEmLista(ramoPrincipal, dados) {


  // Verifica se o Firebase está acessível
  if (typeof db === "undefined" || typeof db.ref !== "function") {
    console.error("❌ Firebase não está corretamente inicializado.");
    alert("❌ Erro interno: Firebase não disponível.");
    return;
  }

  // Captura os campos de RG e Nome
  const rgInput = document.querySelector('input[name="num_documento_id"]');
  const nomeInput = document.querySelector('input[name="nom_compl_envolvido"]');

  const rgValor = rgInput?.value.trim();
  const nomeValor = nomeInput?.value.trim();

  // Validação
  if (!rgValor || !nomeValor) {
    alert("❌Atenção! Falha ao salvar dados.\n\nPasso a passo:\n1. Vá à página de dados pessoais do indivíduo;\n2. Digite o RG;\n3. Clique em 'Preencher Dados Pessoais';\n4. Depois clique em 'Salvar Dados'.");
    return;
  }

  // Referência no Firebase
  const referencia = db.ref(`${ramoPrincipal}/${rgValor}`);
              
  // Salvar dados
  referencia.set(dados)
    .then(() => {



      console.log("✅ Dados salvos com sucesso no Firebase.");

      
      if (typeof mostrarNotificacao === "function") {
        mostrarNotificacao("✅ Dados salvos com sucesso!");
      }

      function clicarSalvar() {
  document.querySelector('input[name="ok"]').click();
}
setTimeout(clicarSalvar, 600);
    })
    .catch((erro) => {
      console.error("❌ Erro ao salvar no Firebase:", erro);
      alert("❌ Falha ao salvar os dados. Veja o console para detalhes.");
    });

    



}






function aguardarBotaoEAtivar() {

 

      // Captura dinâmica dos campos de controle
      const campoPESO = document.querySelector('input[name="vlr_peso_estimado"]');
      const campoRG = document.querySelector('input[name="num_documento_id"]');

      // AÇÕES CONDICIONAIS
      if (campoPESO) {
     mostrarNotificacao("Dados do indivíduo registrados no REDS!");

function clicarSalvar() {
  document.querySelector('input[name="ok"]').click();
}
setTimeout(clicarSalvar, 600);


     // Não faz mais nada
      } else if (campoRG) {

        // 🔽 Executar somente na segunda ação
        const campoFUNCAO = document.querySelector('input[name="des_ocup_profissional"]');
        const campoNOME = document.querySelector('input[name="nom_compl_envolvido"]');
        const campoCPF = document.querySelector('input[name="num_cpf_cnpj"]');
        const campoENDERECO = document.querySelector('input[name="des_endereco"]');
        const campoTELEFONE = document.querySelector('input[name="num_telefone_res"]');
        const campoESCOLARIDADE = document.querySelector('select[name="id_escolaridade"]');
        const campoCOR = document.querySelector('select[name="id_cor_pele"]');
        const campoESTADOCIVEL = document.querySelector('select[name="id_estado_civil"]');
        const campoNascimento = document.querySelector('input[name="dta_nascimento"]');
        const campoNOMEMAE = document.querySelector('input[name="nom_mae"]');
        const campoNOMEPAI = document.querySelector('input[name="nom_pai"]');
        const campoUFNATURALIDADE = document.querySelector('select[name="cod_uf_natural"]');
        const campoNATURALIDADE = document.querySelector('select[name="cod_municipio_naturalidade"]');
        const campoDDDcel = document.querySelector('input[name="ddd_telefone_residencial"]');
        const campoORGAOEXPEDIDOR = document.querySelector('select[name="id_orgao_exp"]');

        let nascimentoFormatado = "NULL";
        if (campoNascimento?.value) {
          const partes = campoNascimento.value.split("/");
          if (partes.length === 3) {
            nascimentoFormatado = `${partes[2]}-${partes[1]}-${partes[0]}`;
          }
        }

        const dadosLista = [
          campoNOME?.value || "NULL",
          campoTELEFONE?.value || "NULL",
          campoRG?.value || "NULL",
          campoCPF?.value || "NULL",
          campoENDERECO?.value || "NULL",
          campoFUNCAO?.value || "NULL",
          campoESCOLARIDADE?.value || "NULL",
          campoCOR?.value || "NULL",
          campoESTADOCIVEL?.value || "NULL",
          campoNOMEMAE?.value || "NULL",
          campoNOMEPAI?.value || "NULL",
          nascimentoFormatado,
          campoUFNATURALIDADE?.value || "NULL",
          campoNATURALIDADE?.value || "NULL",
          campoDDDcel?.value || "NULL",
          campoORGAOEXPEDIDOR?.value || "NULL",
        ];



        
        salvarDadosEmLista("DADOSGERAIS", JSON.stringify(dadosLista));

      } else {
        // Não faz mais nada
        mostrarNotificacao("✅ Dados salvos com sucesso!");

function clicarSalvar() {
  document.querySelector('input[name="ok"]').click();
}
setTimeout(clicarSalvar, 600);

      }
      
  
}



//this funtion changed the page of reds police civil
(function injectForceNewTab() {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('force-new-tab.js');
  script.onload = function () {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);
})();



document.querySelectorAll('div[style*="height:200px"]').forEach(div => {
  div.style.height = 'auto'; // altura nova desejada
});

// Seleciona a div pela classe "conteudo"
const divConteudo = document.querySelector('div.conteudo');

if (divConteudo) {
  divConteudo.style.width = '600px';  // Coloque o valor que quiser aqui
}


// Verifica se a URL atual contém a palavra "relatorio"
if (window.location.href.toLowerCase().includes("relatorio")) {
  console.log("A URL contém 'relatorio'");
  container.style.top = "55px";
  // Ação desejada
  
  // Você pode adicionar outras ações aqui, por exemplo:
  // document.body.style.backgroundColor = "yellow";
} else {
container.style.marginTop = "10px";

};




if (window.location.href.toLowerCase().includes("destinatario")) {
  const orgaoSelect = document.querySelector('select[name="id_orgao_selected"]');

  if (orgaoSelect) {
    orgaoSelect.value = "0"; // Define a opção "POLICIA MILITAR"

    // Dispara o evento de 'change' para chamar automaticamente as funções
    const event = new Event("change", { bubbles: true });
    orgaoSelect.dispatchEvent(event);

setTimeout(() => {
  selecionarMunicipio('SANTA LUZIA');
  setTimeout(() => {
          mostrarNotificacao("✅ Recibo gerado automaticamente para 3 CIA PM IND PVD/3 RPM!");

}, 1000); // tempo em milissegundos
}, 500); // 1000 milissegundos = 1 segundo

  }
}

function selecionarMunicipio(nomeMunicipio) {
  const arvore = document.getElementById('treeMunicipio');
  if (!arvore) {
    console.error('Árvore de municípios não encontrada.');
    return;
  }

  const itens = arvore.querySelectorAll('li.jstree-leaf a');

  for (const item of itens) {
    if (item.textContent.trim().toUpperCase() === nomeMunicipio.toUpperCase()) {
      const li = item.closest('li.jstree-leaf');

      item.click();

      const inputMunicipio = document.querySelector('input[name="nom_municipio_selected"]');
      if (inputMunicipio) {
        inputMunicipio.value = nomeMunicipio;
        inputMunicipio.dispatchEvent(new Event('input', { bubbles: true }));
        inputMunicipio.dispatchEvent(new Event('change', { bubbles: true }));
      }

      // Agora esconde a lista suspensa
      const container = document.getElementById('spanTreeMunicipio');
      if (container) {
        container.style.display = 'none';
      }

      console.log(`Município ${nomeMunicipio} selecionado e lista suspensa fechada.`);
      return;
    }

    setTimeout(() => {
  selecionarUnidade("3 CIA PM IND PVD/3 RPM (M10186)");
}, 500);


  }

  console.warn(`Município ${nomeMunicipio} não encontrado na árvore.`);

  

}




function selecionarUnidade(nomeUnidade) {
  
  const arvore = document.getElementById('tree');
  if (!arvore) {
    console.error('Árvore de unidades não encontrada.');
    return;
  }

  const links = arvore.querySelectorAll('a');

  for (const link of links) {
    if (link.textContent.trim().toUpperCase().startsWith(nomeUnidade.toUpperCase())) {
      link.click();

      // Preenche o input correspondente
      const inputUnidade = document.querySelector('input[name="nome_unidade"]');
      if (inputUnidade) {
        inputUnidade.value = link.textContent.trim();
        inputUnidade.dispatchEvent(new Event('input', { bubbles: true }));
        inputUnidade.dispatchEvent(new Event('change', { bubbles: true }));
      }

      // Fecha a árvore visualmente
      const container = document.getElementById('spanTree');
      if (container) {
        container.style.display = 'none';
      }

      console.log(`Unidade "${link.textContent.trim()}" selecionada.`);
      return;


      
    }

setTimeout(() => {
  const botaoLimpa = document.getElementById("limpaUnidade");
  if (botaoLimpa && document.activeElement === botaoLimpa) {
    botaoLimpa.blur();
  }
}, 100); // tempo em milissegundos




  }

  console.warn(`Unidade "${nomeUnidade}" não encontrada.`);
  
}




window.addEventListener("load", () => {
  const url = window.location.href.toLowerCase();

  if (url.includes("dadosfinais.do")) {

      const meioUtilizado = document.querySelector('select[name="id_instrumento_utilizado"]');
        meioUtilizado.value = 13; // Define a opção "POLICIA MILITAR"

const radioNao = document.querySelector('input[name="ind_pericia_tecnica"][value="N"]');
if (radioNao) {
  radioNao.checked = true;
  radioNao.dispatchEvent(new Event("change", { bubbles: true }));
  radioNao.click(); // dispara o clique para acionar a função onclick associada
}

selecionarItem9700()

// Pega o span com o texto
const span = document.querySelector('.tituloNomeHeader');

if (span) {
  const texto = span.textContent;
  const match = texto.match(/PM(\d{7})/);

  if (match && match[1]) {
    const numero = match[1];

    // Seleciona o input pelo name
    const inputMatricula = document.querySelector('input[name="matricula_relator"]');
    if (inputMatricula) {
      // Preenche o input com o número extraído
      inputMatricula.value = numero;

      // Dispara o evento onchange para chamar a função vinculada
      inputMatricula.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      console.warn('Input matricula_relator não encontrado.');
    }
  } else {
    console.warn('Número PMxxxxxxx não encontrado no texto.');
  }
} else {
  console.warn('Elemento .tituloNomeHeader não encontrado.');
}


  }  
  
});



window.addEventListener("load", () => {
  const url = window.location.href.toLowerCase();

  if (url.includes("atendimento.do")) {
 // alert("deu certo");


const input = document.querySelector('input[name="cod_compl_natureza"]');
input.value = "0115";  // novo valor
input.dispatchEvent(new Event('change', { bubbles: true }));

const input2 = document.querySelector('input[name="cod_compl_local_imediato"]');
input2.value = "1502";  // novo valor
input2.dispatchEvent(new Event('change', { bubbles: true }));

const radioNao = document.querySelector('input[name="ind_movimentacao_financeira"][value="N"]');
if (radioNao) {
  radioNao.checked = true;
  radioNao.dispatchEvent(new Event("change", { bubbles: true }));
  radioNao.click(); // dispara o clique para acionar a função onclick associada
}


const radioNao2 = document.querySelector('input[name="ind_violencia_domestica"][value="N"]');
if (radioNao2) {
  radioNao2.checked = true;
  radioNao2.dispatchEvent(new Event("change", { bubbles: true }));
  radioNao2.click(); // dispara o clique para acionar a função onclick associada
}


} else {
}


  }  
  
);

window.addEventListener("load", () => {
  const url = window.location.href.toLowerCase();

  if (url.includes("inicio.do")) {
//  alert("deu certo");
const input = document.querySelector('input[name="cod_compl_natureza"]');
input.value = "0115";  // novo valor
input.dispatchEvent(new Event('change', { bubbles: true }));

const input2 = document.querySelector('input[name="cod_compl_local_imediato"]');
input2.value = "1502";  // novo valor
input2.dispatchEvent(new Event('change', { bubbles: true }));
const radioNao = document.querySelector('input[name="ind_movimentacao_financeira"][value="N"]');
if (radioNao) {
  radioNao.checked = true;
  radioNao.dispatchEvent(new Event("change", { bubbles: true }));
  radioNao.click(); // dispara o clique para acionar a função onclick associada
}

const radioNao2 = document.querySelector('input[name="ind_violencia_domestica"][value="N"]');
if (radioNao2) {
  radioNao2.checked = true;
  radioNao2.dispatchEvent(new Event("change", { bubbles: true }));
  radioNao2.click(); // dispara o clique para acionar a função onclick associada
}

} else {
}


  }  
  
);

function selecionarItem9700() {
  const grupo9700 = document.querySelector('li[rel="grupo"][title="9700"]');

  if (grupo9700 && grupo9700.classList.contains('jstree-closed')) {
    const linkGrupo = grupo9700.querySelector('a');
    if (linkGrupo) {
      linkGrupo.click(); // Expande o grupo
    }
  }

  setTimeout(() => {
    // Seleciona o item filho real "INEXISTENTE (9700)" (filho do grupo)
    const listaItens = document.querySelectorAll('#treeMotivacao li.jstree-leaf > a');
    let itemFinal = null;

    listaItens.forEach(link => {
      if (link.textContent.trim() === 'INEXISTENTE (9700)') {
        const parent = link.closest('li');
        if (parent && parent.getAttribute('title') === '9700') {
          itemFinal = link;
        }
      }
    });

    if (!itemFinal) {
      console.warn("Item folha 'INEXISTENTE (9700)' não encontrado.");
      return;
    }

    itemFinal.click();

    const input = document.getElementById("treeSearchMotivacao");
    if (input) {
      input.value = "INEXISTENTE (9700)";
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      console.warn("Input #treeSearchMotivacao não encontrado.");
    }

  }, 300); // pode ajustar esse tempo conforme o tempo de expansão do grupo
}


function resetarCamposFormulario() {
  try {
    // Limpa inputs de texto, número e data
    document.querySelectorAll('input[type="text"], input[type="number"], input[type="date"]').forEach(input => {
      input.value = '';
    });

    // Desmarca radios e checkboxes
    document.querySelectorAll('input[type="radio"], input[type="checkbox"]').forEach(input => {
      input.checked = false;
    });

    // Reseta selects
    document.querySelectorAll('select').forEach(select => {
      select.selectedIndex = 0;
      select.dispatchEvent(new Event('change', { bubbles: true }));
    });

    // Campos especiais (exemplo: idade, município)
    const campoIdade = document.querySelector('input[name="vlr_idade_aparente"]');
    if (campoIdade) campoIdade.value = '';

    const campoMunicipio = document.querySelector('select[name="cod_municipio_naturalidade"]');
    if (campoMunicipio) {
      campoMunicipio.selectedIndex = 0;
      campoMunicipio.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Campos com valor padrão após limpeza
    const campoUFRG = document.querySelector('select[name="cod_uf_orgao_exp"]');
    if (campoUFRG) campoUFRG.value = "MG";

    const campoNacionalidade = document.querySelector('select[name="id_nacionalidade"]');
    if (campoNacionalidade) campoNacionalidade.value = "1"; // Brasil

    const campoPaisOrigem = document.querySelector('select[name="id_pais_origem"]');
    if (campoPaisOrigem) campoPaisOrigem.value = "1"; // Brasil

    // Focar novamente no campo de RG
    const campoRG = document.getElementById("rgvitima") || document.querySelector('input[name="num_documento_id"]');
    if (campoRG) {
      campoRG.focus();
      campoRG.select();
    }

  } catch (e) {
    console.error("Erro ao resetar campos do formulário:", e);
    alert("Erro ao limpar os campos do formulário.");
  }
}

const botaoPesquisa = document.getElementById("botaoPesquisaIndividuo");

if (botaoPesquisa) {
  botaoPesquisa.addEventListener("click", (event) => {
    // 🧹 Limpa todos os campos antes da ação original
    resetarCamposFormulario();

    // ✅ Permite que a função inline original ainda seja chamada normalmente
    // Ela será executada porque está no atributo `onclick`, que o navegador também invoca

    console.log("Campos resetados antes da busca.");
  });
} else {
  console.warn('⚠️ Botão com id="botaoPesquisaIndividuo" não encontrado.');
}

function adicionarOpcaoNaoInformadoSituacaoRua() {
  const spanContainer = document.querySelector('span[name="pessoa_situacao_rua_span"]');

  if (!spanContainer) {
    console.warn('⚠️ Elemento pessoa_situacao_rua_span não encontrado.');
    return;
  }

  // Verifica se a opção já existe para evitar duplicações
  const jaExiste = spanContainer.querySelector('input[type="radio"][value="D"]');
  if (jaExiste) {
    console.log("🟢 Opção 'Não informado' já existe.");
    // Garante que essa opção fique marcada
    jaExiste.checked = true;
    return;
  }

  // Cria o input
  const radio = document.createElement("input");
  radio.type = "radio";
  radio.name = "ind_pessoa_situacao_rua";
  radio.value = "D";
  radio.className = "label validationError";
  radio.setAttribute("onclick", "limpaEndereco(this);");

  // Força a seleção do "Não informado"
  radio.checked = true;

  // Cria o label (span com texto)
  const label = document.createElement("span");
  label.className = "label";
  label.textContent = "Não informado";

  // Adiciona os elementos ao DOM
  spanContainer.appendChild(radio);
  spanContainer.appendChild(label);
  spanContainer.appendChild(document.createTextNode('\u00A0')); // espaço

  console.log("✅ Opção 'Não informado' adicionada e selecionada com sucesso.");
}

// Execute a função após o DOM estar carregado
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", adicionarOpcaoNaoInformadoSituacaoRua);
} else {
  adicionarOpcaoNaoInformadoSituacaoRua();
}
