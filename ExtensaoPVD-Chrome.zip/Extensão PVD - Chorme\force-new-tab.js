(function() {
  const originalOpen = window.open;
  window.open = function(url, target, features) {
    // Se o URL for da página de relatório, força abrir em nova aba
    if (typeof url === "string" && url.includes("resumoEvento.do?operation=loadForSearch")) {
      return originalOpen.call(window, url, '_blank');
    }

    // comportamento normal para outros casos
    return originalOpen.call(window, url, target, features);
  };
})();
