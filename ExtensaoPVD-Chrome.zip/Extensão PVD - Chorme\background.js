// ✅ Importando Firebase (porque é módulo)
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

// 🔧 Configuração Firebase
const firebaseConfig = {
  apiKey: "AIzaSyDQWO9csuYqrd0JyXa_cs4f3jAsjQAEWSw",
  authDomain: "meu-site-fd954.firebaseapp.com",
  projectId: "meu-site-fd954",
  storageBucket: "meu-site-fd954.appspot.com",
  messagingSenderId: "1062346912662",
  appId: "1:1062346912662:web:0f41873e12965c545363b7",
  measurementId: "G-5HXX5ZZKER",
  databaseURL: "https://meu-site-fd954-default-rtdb.firebaseio.com"
};

// ✅ Inicializa Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);

